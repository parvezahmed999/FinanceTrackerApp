public class Transaction {
    private String id;
    private String type;
    private double amount;
    private String description;
    private String date;

    public Transaction(String id, String type, double amount, String description, String date) {
        this.id = id;
        setType(type);
        setAmount(amount);
        this.description = description;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public void setType(String type) {
        if (type.equalsIgnoreCase("INCOME") || type.equalsIgnoreCase("EXPENSE")) {
            this.type = type.toUpperCase();
        } else {
            throw new IllegalArgumentException("Type must be 'INCOME' or 'EXPENSE'");
        }
    }

    public void setAmount(double amount) {
        if (amount > 0) {
            this.amount = amount;
        } else {
            throw new IllegalArgumentException("Amount must be positive.");
        }
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return String.format("ID: %s | Type: %s | Amt: %.2f | Desc: %s | Date: %s",
                id, type, amount, description, date);
    }
}