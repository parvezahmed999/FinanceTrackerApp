import java.util.ArrayList;
import java.util.Scanner;

public class FinanceTrackerApp {

    private static ArrayList<Transaction> transactions = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            printMenu();
            System.out.print("Enter your choice: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input! Please enter a number.");
                scanner.next();
                continue;
            }

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    createTransaction();
                    break;
                case 2:
                    readTransactions();
                    break;
                case 3:
                    updateTransaction();
                    break;
                case 4:
                    deleteTransaction();
                    break;
                case 5:
                    calculateBalance();
                    break;
                case 6:
                    System.out.println("Exiting application. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-6.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n=== Personal Finance Tracker ===");
        System.out.println("1. Add Transaction");
        System.out.println("2. View All Transactions");
        System.out.println("3. Update Transaction");
        System.out.println("4. Delete Transaction");
        System.out.println("5. Calculate Balance");
        System.out.println("6. Exit");
        System.out.println("================================");
    }

    private static void createTransaction() {
        System.out.println("\n--- Add New Transaction ---");

        String id;
        while (true) {
            System.out.print("Enter ID: ");
            id = scanner.nextLine();
            if (findTransactionById(id) == null) {
                break;
            }
            System.out.println("Error: A transaction with this ID already exists. Try again.");
        }

        String type;
        while (true) {
            System.out.print("Enter Type (INCOME/EXPENSE): ");
            type = scanner.nextLine().toUpperCase();
            if (type.equals("INCOME") || type.equals("EXPENSE")) {
                break;
            }
            System.out.println("Invalid type. Please enter 'INCOME' or 'EXPENSE'.");
        }

        double amount;
        while (true) {
            System.out.print("Enter Amount: ");
            if (scanner.hasNextDouble()) {
                amount = scanner.nextDouble();
                scanner.nextLine();
                if (amount > 0) break;
                System.out.println("Amount must be positive.");
            } else {
                System.out.println("Invalid number. Please enter a valid amount.");
                scanner.next();
            }
        }

        System.out.print("Enter Description: ");
        String description = scanner.nextLine();

        System.out.print("Enter Date (YYYY-MM-DD): ");
        String date = scanner.nextLine();

        Transaction newTrans = new Transaction(id, type, amount, description, date);
        transactions.add(newTrans);
        System.out.println("Transaction added successfully!");
    }

    private static void readTransactions() {
        System.out.println("\n--- All Transactions ---");
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
        } else {
            System.out.printf("%-10s %-10s %-10s %-20s %-12s%n", "ID", "TYPE", "AMOUNT", "DESCRIPTION", "DATE");
            System.out.println("-----------------------------------------------------------------");
            for (Transaction t : transactions) {
                System.out.printf("%-10s %-10s $%-9.2f %-20s %-12s%n",
                        t.getId(), t.getType(), t.getAmount(), t.getDescription(), t.getDate());
            }
        }
    }

    private static void updateTransaction() {
        System.out.println("\n--- Update Transaction ---");
        System.out.print("Enter ID to update: ");
        String id = scanner.nextLine();

        Transaction t = findTransactionById(id);

        if (t != null) {
            System.out.println("Transaction found: " + t);

            while (true) {
                System.out.print("Enter New Type (INCOME/EXPENSE): ");
                String type = scanner.nextLine().toUpperCase();
                if (type.equals("INCOME") || type.equals("EXPENSE")) {
                    t.setType(type);
                    break;
                }
                System.out.println("Invalid type.");
            }

            while (true) {
                System.out.print("Enter New Amount: ");
                if (scanner.hasNextDouble()) {
                    double amount = scanner.nextDouble();
                    scanner.nextLine();
                    if (amount > 0) {
                        t.setAmount(amount);
                        break;
                    }
                    System.out.println("Amount must be positive.");
                } else {
                    System.out.println("Invalid input.");
                    scanner.next();
                }
            }

            System.out.print("Enter New Description: ");
            t.setDescription(scanner.nextLine());

            System.out.print("Enter New Date (YYYY-MM-DD): ");
            t.setDate(scanner.nextLine());

            System.out.println("Transaction updated successfully!");

        } else {
            System.out.println("Transaction with ID " + id + " not found.");
        }
    }

    private static void deleteTransaction() {
        System.out.println("\n--- Delete Transaction ---");
        System.out.print("Enter ID to delete: ");
        String id = scanner.nextLine();

        Transaction t = findTransactionById(id);

        if (t != null) {
            transactions.remove(t);
            System.out.println("Transaction " + id + " deleted successfully.");
        } else {
            System.out.println("Transaction not found.");
        }
    }

    private static void calculateBalance() {
        double totalIncome = 0;
        double totalExpense = 0;

        for (Transaction t : transactions) {
            if (t.getType().equals("INCOME")) {
                totalIncome += t.getAmount();
            } else if (t.getType().equals("EXPENSE")) {
                totalExpense += t.getAmount();
            }
        }

        double balance = totalIncome - totalExpense;

        System.out.println("\n--- Financial Summary ---");
        System.out.printf("Total Income:  $%.2f%n", totalIncome);
        System.out.printf("Total Expense: $%.2f%n", totalExpense);
        System.out.println("-------------------------");
        System.out.printf("Net Balance:   $%.2f%n", balance);
    }

    private static Transaction findTransactionById(String id) {
        for (Transaction t : transactions) {
            if (t.getId().equals(id)) {
                return t;
            }
        }
        return null;
    }
}